/******************************************************************************
 * Author:     Edmund Dea
 * Student Id: 933280343
 * Date:       3/15/17
 * Class:      CS290
 * Title:      Week 9 - HW Assignment: Database and Interactions
 * Filename:   scripts.js
 ******************************************************************************/

/* Reference: 
 * https://stackoverflow.com/questions/8624093/node-js-submit-form 
 */
$("#form1").submit(function(e) {
    e.preventDefault();

    var $this = $(this);
    var name = $("#form1 input[id='name']").val();
    var reps = $("#form1 input[id='reps']").val();
    var weight = $("#form1 input[id='weight']").val();
    var date = $("#form1 input[id='date']").val();
    var lbs = $("#form1 input[name='lbs']:checked").val();
    var ajaxData = [name, reps, weight, date, lbs];
    var postData = $this.serialize() + "&cmd=insert";

    // Validate input
    // Reference for Date Format: https://stackoverflow.com/questions/22061723/regex-date-validation-for-yyyy-mm-dd
    var isNumber = new RegExp("^-?[0-9]{1,}$");
    var isDate =  new RegExp("^[0-9]{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])$");

    if (!name || name.length === 0) {
        alert("Error: Name is invalid.");
        return;
    }
    if (lbs === undefined) {
        alert("Error: Lbs or Kilos must be selected.");
        return;
    }
    if (!reps || reps.length === 0 || !isNumber.test(reps)) {
        alert("Error: Reps is invalid.");
        return;
    }
    if (!weight || weight.length === 0 || !isNumber.test(weight)) {
        alert("Error: Weight is invalid.");
        return;
    }
    if (!date || date.date === 0 || !isDate.test(date)) {
        alert("Error: Date is invalid.");
        return;
    }

    $.ajax({
        type: 'POST',
        url: $this.attr("action"),
        data: postData,
        success: function(data) {
            var obj = JSON.parse(data);
            ajaxData.id = obj.insertId;
            insertRow(ajaxData);
        },
        error: function(jqXHR, textStatus) { 
            console.log("[AJAX Error] " + textStatus);
        },
        complete: function(jqXHR, textStatus) { 
            //console.log("[AJAX Complete] " + textStatus); 
        },
        datatype: 'json'
    });
});

function insertRow(data) {
    var table = document.getElementById("workout_table");

    var tr = document.createElement("tr");

    var id = document.createElement("input");
    id.setAttribute("type", "hidden");
    id.setAttribute("value", data.id);
    tr.appendChild(id);

    for (var prop in data) {
        if (!(prop === "id")) {
            var td = document.createElement("td");
            td.textContent = data[prop];
            tr.appendChild(td);
        }
    }

    var editButton = document.createElement("button");
    editButton.setAttribute("type", "button");
    editButton.setAttribute("onclick", "editRow(this, " + data.id + ")");
    editButton.classList.add("td_button");
    editButton.textContent = "Edit";
    tr.appendChild(editButton);

    var deleteButton = document.createElement("button");
    deleteButton.setAttribute("type", "button");
    deleteButton.setAttribute("onclick", "deleteRow(this, " + data.id + ")");
    deleteButton.classList.add("td_button");
    deleteButton.textContent = "Delete";
    tr.appendChild(deleteButton);

    table.appendChild(tr);
}

function editRow(btn, id) {
    var row = btn.parentNode.parentNode;
    var data = {cmd : "edit", id : id};
    var $this = $(this);

    $.ajax({
        type: 'POST',
        url: $this.closest("button").attr("action"),
        data: data,
        success: function(data) {},
        error: function(jqXHR, textStatus) { 
            console.log("[AJAX Error] " + textStatus);
        },
        complete: function(jqXHR, textStatus) { 
            //console.log("[AJAX Complete] " + textStatus); 
        },
        datatype: 'json'
    });
}

function deleteRow(btn, id) {
    var row = btn.parentNode;
    var data = {cmd : "delete", id : id};
    var $this = $(this);

    console.log("delete id " + id);

    $.ajax({
        type: 'POST',
        url: $this.closest("button").attr("action"),
        data: data,
        success: function(data) {},
        error: function(jqXHR, textStatus) { 
            console.log("[AJAX Error] " + textStatus);
        },
        complete: function(jqXHR, textStatus) { 
            //console.log("[AJAX Complete] " + textStatus); 
        },
        datatype: 'json'
    });


    /* Delete the row using DOM manipulation
     * Reference: https://stackoverflow.com/questions/13241005/add-delete-row-from-a-table
     */
    row.parentNode.removeChild(row);
}
